let i = 0;
setInterval(() => {
    if(i < document.getElementById("slike").children.length - 2){
        document.getElementById("slike").children[i].style.display = "none";
        document.getElementById("slike").children[i + 1].style.display = "block";

        document.getElementById("kruzici").children[i].classList.remove("active");
        document.getElementById("kruzici").children[i + 1].classList.add("active");
        
    }
    else{
        i = 0;
        document.getElementById("slike").children[i].style.display = "none";
        document.getElementById("slike").children[i + 1].style.display = "block";

        document.getElementById("kruzici").children[i].classList.remove("active");
        document.getElementById("kruzici").children[i + 1].classList.add("active");
    }
    i++;
}, 3000);